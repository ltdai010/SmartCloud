public class StudentManagement {
    public Student[] student = new Student[100];
    private int numberOfStudents = 0;

    public static void main(String[] args) {
        StudentManagement studentManagement = new StudentManagement();
        Student Diaz = new Student("Diaz", "18020263", "ltdai@gmail.com");
        Student Yuri = new Student("Yuri", "18020221", "l555@gmail.com");
        Student Jason = new Student("Jason", "1805521", "4444@gmail.com");
        Jason.setGroup("K63-CC");
        studentManagement.addStudent(Diaz);
        studentManagement.addStudent(Yuri);
        studentManagement.addStudent(Jason);
        System.out.println(sameGroup(studentManagement.student[0], studentManagement.student[2]));
        studentManagement.removeStudent("1805521");
        System.out.println(studentManagement.studentsByGroup());
    }

    public static boolean sameGroup(Student s1, Student s2) {
        return (s1.getGroup() == s2.getGroup());
    }

    public void addStudent(Student newStudent) {
        ++numberOfStudents;
        if (numberOfStudents > 100) {
            System.out.println("Failed to add data. ERROR: OVER MAX STUDENT'S NUMBER");
            return;
        }
        student[numberOfStudents - 1] = newStudent;
    }

    public String studentsByGroup() {
        String groupString = "";
        boolean[] inGroup = new boolean[numberOfStudents];
        for (int i = 0; i < numberOfStudents; ++i) {
            inGroup[i] = false;
        }
        for (int i = 0; i < numberOfStudents; ++i) {
            if (inGroup[i] == false) {
                groupString = groupString + this.student[i].getGroup() + "\n" + this.student[i].getInfo() + "\n";
                for (int j = i + 1; j < numberOfStudents; ++j) {
                    if (this.student[i].getGroup() == this.student[j].getGroup()) {
                        inGroup[j] = true;
                        groupString = groupString + this.student[j].getInfo() + "\n";
                    }
                }
            }
        }
        return groupString;
    }

    public void removeStudent(String id)
    {
        for(int i = 0; i < numberOfStudents; ++i)
        {
            if (this.student[i].getID() == id)
            {
                for (int j = i; j < numberOfStudents - 1; ++j) {
                    this.student[i] = this.student[i + 1];
                }
                this.student[numberOfStudents] = null;
            }
        }
        numberOfStudents--;
    }
}
